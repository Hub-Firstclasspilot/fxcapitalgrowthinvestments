

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="row align-items-center">
        <div class="col-md-6">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('login')); ?>" style="position: relative;">
                    <?php echo csrf_field(); ?>
                <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('images/logos/logo.png')); ?>" width="80" alt="" class="img-fluid mb-4"></a>
                <div style="position: absolute; top: 23px; right:2px; display: flex; justify-content: space-between; width:20%;">
                    <img src="<?php echo e(asset('images/logos/bitcoin-single.png')); ?>" style="width: 45%; height: 55%; margin-top:6%;">
                    <img src="<?php echo e(asset('images/logos/ethereum.png')); ?>" style="width: 35%; height: 40%;">
                </div>

                <h4 class="mb-3 f-w-400">Login into your account</h4>
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="feather icon-mail"></i></span>
                    </div>
                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email address" name="email"value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="feather icon-lock"></i></span>
                    </div>
                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password" required autocomplete="current-password">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group text-left mt-2">
                    <div class="checkbox checkbox-primary d-inline">
                        <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <label for="checkbox-fill-a1" class="cr"> Remember me</label>
                    </div>
                </div>
                <button class="btn btn-primary mb-4" name="loginbtn">Login</button>
                <p class="mb-2 text-muted">Forgot password? <a href="<?php echo e(route('password.request')); ?>" class="f-w-400">Reset</a></p>
                <p class="mb-0 text-muted">Don’t have an account? <a href="<?php echo e(route('register')); ?>" class="f-w-400">Signup</a></p>
                </form>
                
                <div style="width: 90%; margin: 5% auto;">
                    <img src="<?php echo e(asset('images/logos/pay-strip.jpeg')); ?>" style="width:80%;">
                </div>

            </div>
        </div>
        <div class="col-md-6 d-none d-md-block">
            <img src="<?php echo e(asset('auth/images/auth-bg.jpg')); ?>" alt="" class="img-fluid">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Sites\PHP\fxcapital-investments\resources\views/auth/login.blade.php ENDPATH**/ ?>