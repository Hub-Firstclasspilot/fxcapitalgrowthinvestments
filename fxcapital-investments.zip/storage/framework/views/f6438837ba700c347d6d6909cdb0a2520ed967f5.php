<?php $__env->startSection('title'); ?>
    <?php echo "Request A Loan"; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
            <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">Hello, <?php echo e($user->username); ?></h4>
                    </div>
                    <div class="text-right col-md-7 align-self-center">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Withdawals</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <?php
                    switch ($user->account->account_currency) {
                        case 'GBP':
                            $symbol = '£';
                            break;

                        case 'EUR':
                            $symbol = '€';
                            break;

                        case 'Bitcoin':
                            $symbol = '₿';
                            break;

                        default:
                            $symbol = '$';
                            break;
                    }

                    $deposits = [];
                    /*
                    if ($user->deposits->toArray()) {
                        foreach ($user->desposits->toArray() as $deposit) {
                        $deposits += $deposit->amount;
                    }
                    }
                    if ($user->withdrawals->toArray()) {
                        $withdrawals = count($user->withdawals->toArray());
                    } */
                ?>
                <?php echo $__env->make('admin.partials.widgets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <div class="mt-5 row">
                    <!-- Column -->
                    <div class="mx-auto col-lg-12 col-xlg-12 col-md-12">
                        <div class="card">
                            <div class="text-white card-header bg-primary">
                                <h2 class="card-title">Personal info about yourself</h2>
                            </div>

                            <div class="card-body">
                                <form action="<?php echo e(route('request-loan', $user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="name">Fullname</label>
                                    <input type="text"
                                    class="form-control" name="fullname" id="name" value="<?php echo e($user->firstname." ".$user->lastname); ?>" readonly>
                                </div>

                                <input type="hidden" value="<?php echo e(uniqid()); ?>" name="request_code">

                                <div class="form-group">
                                    <label for="duration">Duration of loan (in months)</label>
                                    <input type="number"
                                    class="form-control" name="loan_duration" id="duration" placeholder="Time period for the loan (eg. 2 months)">
                                </div>

                                <div class="form-group">
                                    <label for="amount">Loan Amount (<?php echo e($symbol); ?>)</label>
                                    <input type="number"
                                    class="form-control" name="loan_amount" id="amount" placeholder="Amount">
                                </div>

                                <div class="form-group">
                                    <label for="reason">Reason for the loan</label>
                                    <textarea class="form-control" name="loan_reason" id="reason" rows="3" placeholder="Why do you want the loan?"></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                            </form>
                            </div>
                        </div>
                    </div>
                <!-- Column -->
                </div>

            </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Sites\PHP\fxcapital-investments\resources\views/admin/pages/loan-request.blade.php ENDPATH**/ ?>