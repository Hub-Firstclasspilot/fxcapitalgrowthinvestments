<!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer">
          <img src="<?php echo e(asset('images/logos/logo.png')); ?>" alt="logo" width="40" height="40">  © <script>document.write(new Date().getFullYear())</script> Fx Capital Growth Investment Group
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
<?php /**PATH C:\Sites\PHP\fxcapital-investments\resources\views/admin/partials/_footer.blade.php ENDPATH**/ ?>