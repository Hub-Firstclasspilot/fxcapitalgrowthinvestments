<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FX Capital Investments - <?php echo e($title ?? ""); ?></title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>
    
    <header>
        <nav class="navbar navbar-expand-sm navbar-light bg-light text-uppercase d-flex justify-items-center" id="navbar">
            <a class="navbar-brand" href="#">Logo</a>
            <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse mx-auto" id="collapsibleNavId">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/service">Service</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/contact">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/login">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/register">Register</a>
                    </li>
                    
                </ul>
                
            </div>
        </nav>
        <div class="hero">
            <h2 class="text-sm">FXINFOINVESTMENT COMPANY</h2>
            <h4>Clever <span class="text-blue">Investing</span> makes your money grow</h4>
            <p class="text-muted">Trade Stock indices</p>
            <p class="text-muted">Commodities and Forex from a single account with the recommended funds to achieve your financial goals</p>

            <a href="" class="btn-main btn-blue">Work with us</a>
        </div>
    </header>
        
        <?php echo $__env->yieldContent('content'); ?>


    <footer class="bg-main-blue text-white p-5">
        <div class="row d-flex">
            <div class="col-4">
                <h4>Call Us Directly</h4>
                <a href="tel:+1332336920">+1332-233-6920</a>
                <a href="mailto:support@fxinfoinvestment.com">support@fxinfoinvestment.com</a>
            </div>
            <div class="col-4">
                <h3>Company</h3>
                <ul>
                    <li><a href="/">Home</a></li>
                    <li><a href="/dashboard">My Account</a></li>
                    <li><a href="/about">About Us</a></li>
                    <li><a href="/terms">Terms/Policies</a></li>
                </ul>
            </div>
            <div class="col-4">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="/register">Register</a></li>
                    <li><a href="#contact">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-4">
                <h3>Our Newsletter</h3>
                <p>Subscribe to our newsletter and we will inform you about the latest updates and offers</p>

                <form action="" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                      <input type="text"
                        class="form-control" name="email" id="email" aria-describedby="helpId" placeholder="Email Address..">
                    </div>
                </form>
            </div>

            <hr class="text-white my-3">
        </div>
    </footer>
    
    
    

    

    
    


    
    


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script>
        $('#navId a').click(e => {
            e.preventDefault();
            $(this).tab('show');
        });
    </script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Sites\PHP\fxcapital-investments\resources\views/layout/app.blade.php ENDPATH**/ ?>