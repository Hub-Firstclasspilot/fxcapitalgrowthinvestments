<!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer">
          <img src="{{ asset('images/logos/logo.png') }}" alt="logo" width="40" height="40">  © <script>document.write(new Date().getFullYear())</script> Fx Capital Growth Investment Group
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
